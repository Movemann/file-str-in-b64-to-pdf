/** Daniel.C.G.
 * 1 - Input: file .txt 
 * 2 - Process: .txt file contains string base64 to convert
 * 3 - Output:  .PDF file from String b64  
 * **/

import java.io.File;
import java.io.FileNotFoundException; 
import java.io.FileOutputStream;
import java.util.Base64;
import java.util.Scanner;

public class ReadFile {
		
	static String str = null;
	
	public static void main(String[] args) {
	    try {
	      /* INPUT */
	      File myObj = new File("test.txt");
	      Scanner myReader = new Scanner(myObj);
	      while (myReader.hasNextLine()) {
	        String data = myReader.nextLine();
	        System.out.println("Data readed: "+data);
	        str=data;
	      }
	      myReader.close();
	    } catch (FileNotFoundException e) {
	      try {
			System.out.println("An error occurred reading files!");
		} catch (Exception e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
	      e.printStackTrace();
	    }
	    
	    /* OUTPUT */
	    File file = new File("./test2.pdf");
	    try ( FileOutputStream fos = new FileOutputStream(file); ) {
	      // To be short I use a corrupted PDF string, so make sure to use a valid one if you want to preview the PDF file
	      String b64 = str;
	      byte[] decoder = Base64.getDecoder().decode(b64);
	      fos.write(decoder);
	      try {
			System.out.println("Process Completed, File Saved as PDF !");
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	    } catch (Exception e) {
	      e.printStackTrace();
	    }
	    
	  }
	}
	
	
	
